package com.accenture.pessoa_swagger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan; // Adicione este import
import org.springframework.data.jpa.repository.config.EnableJpaRepositories; // Adicione este import

@SpringBootApplication
@EntityScan("com.accenture.pessoa.entity") // Onde estão suas classes @Entity
@EnableJpaRepositories("com.accenture.pessoa.repository") // Onde está seu PessoaRepository
public class PessoaSwaggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PessoaSwaggerApplication.class, args);
	}

}